<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="gl_ES">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../cmd.cpp" line="142"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../cmd.cpp" line="143"/>
        <source>This operation requires administrator privileges. The change was not applied. Please try again and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MEConfig</name>
    <message>
        <location filename="../mainwindow.ui" line="20"/>
        <source>MX User Manager</source>
        <translation>MX Xestor de usuarios</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="65"/>
        <source>Administration</source>
        <translation>Administración</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="68"/>
        <source>Add a new user</source>
        <translation>Engadir a un novo usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="296"/>
        <source>Add User Account</source>
        <translation>Engadir conta de usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="323"/>
        <source>Enter password for new user</source>
        <translation>Inserir contrasinal para o novo usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="332"/>
        <source>password</source>
        <translation>contrasinal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="364"/>
        <source>Reenter password for new user</source>
        <translation>Reintroducir o contrasinal para o novo usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="373"/>
        <source>confirm password</source>
        <translation>confirmar o contrasinal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="389"/>
        <source>Username of new user</source>
        <translation>Nome do usuario do novo usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>User login name:</source>
        <translation>Nome de acceso do usuario:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="165"/>
        <location filename="../mainwindow.ui" line="408"/>
        <source>Enter username of new user</source>
        <translation>Introducir o nome do usuario do novo usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="171"/>
        <location filename="../mainwindow.ui" line="414"/>
        <source>username</source>
        <translation>nome do usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="430"/>
        <location filename="../mainwindow.ui" line="449"/>
        <source>Password for new user</source>
        <translation>COntrasinal para o novo usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="433"/>
        <source>Confirm user password:</source>
        <translation>Confirmar o contrasinal do usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="452"/>
        <source>User password:</source>
        <translation>Contrasinal do usuario:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="462"/>
        <source>Grant this user administrative rights to the system (sudo)</source>
        <translation>Concede a este usuario dereitos administrativos no sistema (sudo)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="190"/>
        <source>Delete User Account</source>
        <translation>Eliminar conta do usuari</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="233"/>
        <location filename="../mainwindow.ui" line="506"/>
        <source>Select user</source>
        <translation>Seleccionar usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="249"/>
        <location filename="../mainwindow.ui" line="1442"/>
        <source>Select user to delete</source>
        <translation>Seleccionar usuario para eliminar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="258"/>
        <source>User to delete:</source>
        <translation>Usuario a eliminar:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="274"/>
        <source>Also delete the user&apos;s home directory</source>
        <translation>Tamén eliminar o directorio de home do usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="277"/>
        <source>Delete user home directory</source>
        <translation>Eliminar o directorio de home do usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="95"/>
        <source>Rename User Account</source>
        <translation>Renomear a conta do usuari</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="107"/>
        <location filename="../mainwindow.ui" line="576"/>
        <source>Select user to modify:</source>
        <translation>Seleccionar usuario para modificar:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="149"/>
        <source>New user name:</source>
        <translation>Novo nome do usuario:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="494"/>
        <source>Change User Password</source>
        <translation>Cambiar o contrasinal do usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="525"/>
        <source>new password</source>
        <translation>novo contrasinal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="541"/>
        <source>Confirm new password:</source>
        <translation>Confirmar novo contrasinal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="560"/>
        <source>confirm new password</source>
        <translation>confirmar novo contrasina</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="592"/>
        <source>New user password:</source>
        <translation>Contrasinal do novo usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="626"/>
        <source>Options</source>
        <translation>Opcións</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="629"/>
        <source>Repair a user configuration</source>
        <translation>Reparar a configuración do usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="663"/>
        <location filename="../mainwindow.ui" line="1399"/>
        <source>Modify User Account</source>
        <translation>Modificar a conta do usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="675"/>
        <location filename="../mainwindow.ui" line="691"/>
        <source>Select user to repair</source>
        <translation>Seleccionar usuario para reparar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="678"/>
        <location filename="../mainwindow.ui" line="1451"/>
        <source>User to change:</source>
        <translation>Usuario a modificar:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="723"/>
        <source>Restore Defaults</source>
        <translation>Restablecer a configuración predeterminada</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="744"/>
        <source>Restore browser configs to MX defaults</source>
        <translation>Restaurar as configuracións do navegador para as predeterminadas do MX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="750"/>
        <source>Mozilla (Iceweasel or Firefox) configs</source>
        <translation>Configuración do Mozilla (Iceweasel ou Firefox(</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="753"/>
        <source>Alt+X</source>
        <translation>Alt+X</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="760"/>
        <source>Restore group memberships to MX defaults</source>
        <translation>Restaurar os membros do grupo para os predeterminados de MX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="766"/>
        <source>Group memberships</source>
        <translation>Membros do grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="769"/>
        <source>Alt+G</source>
        <translation>Alt+G</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="779"/>
        <source>Change Autologin Settings</source>
        <translation>Cambiar a configuracion do inicio de sesión automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="785"/>
        <source>Log in automatically</source>
        <translation>Iniciar sesión automaticamente</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="792"/>
        <source>Require password to log in</source>
        <translation>Requerido contrasinal para iniciar sesión</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="807"/>
        <source>Copy/Sync</source>
        <translation>Copiar/Sincronizar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="834"/>
        <source>Copy Between Desktops</source>
        <translation>Copiar entre escritorios</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="861"/>
        <location filename="../mainwindow.ui" line="928"/>
        <source>Select desktop to copy from</source>
        <translation>Seleccionar escritorio de onde copiar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="874"/>
        <source>Select to only copy files</source>
        <translation>Seleccionar para só copiar ficheiros</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="877"/>
        <source>Copy only</source>
        <translation>Só copiar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="893"/>
        <location filename="../mainwindow.ui" line="906"/>
        <source>Select desktop to copy to</source>
        <translation>Seleccionar o escritorio para onde copiar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="915"/>
        <source>Copy to:</source>
        <translation>Copiar a:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="937"/>
        <source>Copy from:</source>
        <translation>Copiar de:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="950"/>
        <source>Select to copy and then delete differences</source>
        <translation>Seleccionar para copiar e de seguida eliminar diferenzas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="953"/>
        <source>Sync</source>
        <translation>Sincronizar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="999"/>
        <source>Select to copy/sync Shared</source>
        <translation>Seleccionar para copiar/sincronizar intercambiadas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1002"/>
        <source>Shared folder</source>
        <translation>Cartafol compartido</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1015"/>
        <source>Select to copy/sync entire home</source>
        <translation>Seleccionar para copiar/sincronizar todo o cartafol persoal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1018"/>
        <source>Entire home</source>
        <translation>Todo o cartafol persaol</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1034"/>
        <source>Select to copy/sync the browser configuration</source>
        <translation>Seleccionar par copiar/sincronizar a configuración do navegador</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1037"/>
        <source>Mozilla (Firefox or Iceweasel) configs</source>
        <translation>Configuración para Mozilla (Iceweasel ou Firefox)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1050"/>
        <source>Select to copy/sync Documents</source>
        <translation>Seleccionar para copiar/sincronizar o cartafol Documentos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1053"/>
        <source>Documents folder</source>
        <translation>Cartafol Documentos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1060"/>
        <source>What to copy/sync:</source>
        <translation>Que copiar/sincronizar:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1076"/>
        <source>Progress</source>
        <translation>Progreso</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1106"/>
        <location filename="../mainwindow.ui" line="1122"/>
        <source>Status of the changes</source>
        <translation>Estado dos cambios</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1125"/>
        <source>Status:</source>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1141"/>
        <source>Progress of the changes</source>
        <translation>Progreso dos cambios</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1178"/>
        <source>Add/Remove Groups</source>
        <translation>Engadir/eliminar grupos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1190"/>
        <source>Add Group</source>
        <translation>Engadir grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1217"/>
        <source>Enter name of new group</source>
        <translation>Introduza o nome do novo grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1223"/>
        <source>groupname</source>
        <translation>nomedogrupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1233"/>
        <source>Create a group with GID &gt; 1000</source>
        <translation>Crear un grupo con GID &gt; 1000</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1236"/>
        <source>Create a user-level group</source>
        <translation>Crear un grupo de nivel de usuario</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1265"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter name of new group&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Introduza o nome do novo grupo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1268"/>
        <source>Group name:</source>
        <translation>Nome do grupo:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1287"/>
        <source>Delete Group</source>
        <translation>Eliminar grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1356"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select group to delete&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona o grupo a eliminar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1365"/>
        <source>Select group to delete:</source>
        <translation>Selecciona o grupo a eliminar:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1372"/>
        <source>*Please doublecheck your selections before applying, removing a wrong group can break your system.</source>
        <translation>*Por favor, verifique as suas seleções antes de aplicar, remover um grupo errado pode danificar o seu sistema.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1387"/>
        <source>Group Membership</source>
        <translation>Membros do grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1461"/>
        <source>Groups user belongs to (change the groups by selecting/deselecting the appropriate boxes):</source>
        <translation>Grupos a que o usuario pertence (cambiar os grupos marcando ou desmarcando as respectivas caixas):</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1484"/>
        <source>*Please doublecheck your selections before applying, assigning wrong group memberships can break your system. If you made a mistake, use restore group membership in Options tab to restore the defaults.</source>
        <translation>*Por favor, verifique as súas seleccións antes de aplicar, asignar membros incorrectos a un grupo pode romper o seu sistema. Se cometeu un erro, use a opción de restaurar membros do grupo na lapela de Opcións para restaurar os valores predeterminados.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1513"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select user to change&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecciona o usuario a cambiar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1589"/>
        <source>Cancel any changes then quit</source>
        <translation>Cancelar os cambios e saír</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1592"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1598"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1639"/>
        <source>Display help </source>
        <translation>Amosar axuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1642"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1648"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1655"/>
        <source>Apply any changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1658"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1664"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1671"/>
        <source>About this application</source>
        <translation>Sobre esta aplicación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1674"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1680"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="316"/>
        <location filename="../mainwindow.cpp" line="324"/>
        <location filename="../mainwindow.cpp" line="351"/>
        <location filename="../mainwindow.cpp" line="1042"/>
        <location filename="../mainwindow.cpp" line="1072"/>
        <location filename="../mainwindow.cpp" line="1424"/>
        <location filename="../mainwindow.cpp" line="1500"/>
        <location filename="../mainwindow.cpp" line="1507"/>
        <location filename="../mainwindow.cpp" line="1512"/>
        <location filename="../mainwindow.cpp" line="1517"/>
        <location filename="../mainwindow.cpp" line="1522"/>
        <source>none</source>
        <translation>ningunha</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="294"/>
        <location filename="../mainwindow.cpp" line="987"/>
        <location filename="../mainwindow.cpp" line="1431"/>
        <location filename="../mainwindow.cpp" line="1449"/>
        <source>browse...</source>
        <translation>navegador...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="367"/>
        <source>The user configuration will be repaired. Please close all other applications now. When finished, please logout or reboot. Are you sure you want to repair now?</source>
        <translation>A configuración do usuario será reparada. Pechar todos os outros aplicativos agora. Cando estea concluído, saír da sesión ou reiniciar. Proceder á reparación agora?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="409"/>
        <source>User group membership was restored.</source>
        <translation>A pertenza ao grupo de usuarios foi restaurada.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="418"/>
        <source>Mozilla settings were reset.</source>
        <translation>A configuración do Mozilla foi restablecida.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="428"/>
        <location filename="../mainwindow.cpp" line="431"/>
        <location filename="../mainwindow.cpp" line="451"/>
        <location filename="../mainwindow.cpp" line="454"/>
        <source>Autologin options</source>
        <translation>Opcións de acceso automático</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="429"/>
        <source>Autologin has been disabled for the &apos;%1&apos; account.</source>
        <translation>O acceso automático foi desactivado para a conta &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="452"/>
        <source>Autologin has been enabled for the &apos;%1&apos; account.</source>
        <translation>O acceso automático foi activado para a conta &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="469"/>
        <source>You must specify a &apos;copy to&apos; destination. You cannot copy to the desktop you are logged in to.</source>
        <translation>É necesario especificar un destino onde &apos;copiar a&apos;. Non é posible copar para o escritorio da sesión.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="481"/>
        <source>Before copying, close all other applications. Be sure the copy to destination is large enough to contain the files you are copying. Copying between desktops may overwrite or delete your files or preferences on the destination desktop. Are you sure you want to proceed?</source>
        <translation>Antes de copiar, pechar todos os outros aplicativos. Certificarse de que o destino de &apos;copiar a&apos; é suficientemente grande para recibir todos os ficheiros a copiar. Copiar entre escritorios pode escribir por riba de, ou borrar, ficheiros ou preferencias do escritorio de destino. Continuar?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="518"/>
        <source>Synchronizing desktop...</source>
        <translation>Sincronizando escritorio...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="520"/>
        <source>Copying desktop...</source>
        <translation>Copiando escritorio...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="551"/>
        <location filename="../mainwindow.cpp" line="833"/>
        <source>The user name needs to be at least 2 characters long. Please select a longer name before proceeding.</source>
        <translation>O nome do usuario ten que te rpolo menos 2 caracteres. Escoller un nome do usuario máis cumprido.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="556"/>
        <location filename="../mainwindow.cpp" line="838"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>O nome de usuario non pode conter caracteres especiais ou espazos. Escoller outro nome antes de proseguir.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="562"/>
        <source>Sorry, this name is in use. Please enter a different name.</source>
        <translation>Este nome xa está en uso. Introducir un nome diferente.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="566"/>
        <location filename="../mainwindow.cpp" line="652"/>
        <source>Password entries do not match. Please try again.</source>
        <translation>Os contrasinais non coinciden. Intentar de novo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="622"/>
        <source>The user was added ok.</source>
        <translation>O usuario foi engadido correctamente.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="609"/>
        <location filename="../mainwindow.cpp" line="637"/>
        <source>Failed to add the user.</source>
        <translation>Fallou engadir ao usuario.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="309"/>
        <source>Add user to %1 group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="392"/>
        <source>No default extra groups are configured on this system.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="411"/>
        <source>Could not restore the user&apos;s group membership.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="420"/>
        <source>Could not reset the Mozilla settings.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="432"/>
        <source>Autologin could not be disabled for the &apos;%1&apos; account.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="455"/>
        <source>Autologin could not be enabled for the &apos;%1&apos; account.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="475"/>
        <location filename="../mainwindow.cpp" line="1438"/>
        <source>You cannot copy to the source desktop or the desktop you are logged in to.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="571"/>
        <location filename="../mainwindow.cpp" line="657"/>
        <source>The password cannot be empty. Please enter a password before proceeding.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="590"/>
        <source>No suitable user management tools found (adduser or useradd).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="640"/>
        <source>The user %1 was created, but its password could not be set. Set a password for it or delete it on the Administration tab.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>Password successfully changed.</source>
        <translation>O contrasinal foi cambiado.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="667"/>
        <source>Failed to change password.</source>
        <translation>Fallou o cambio do contrasinal.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="678"/>
        <source>To delete this user, please log out and log back in using another user account.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="683"/>
        <source>This action cannot be undone. Are you sure you want to delete user %1?</source>
        <translation>Esta acción non pode ser revertida. Eliminar o usuario %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="691"/>
        <source>No suitable user removal tools found (deluser or userdel).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="706"/>
        <source>The user has been deleted.</source>
        <translation>O usuario foi eliminado.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="708"/>
        <source>Failed to delete the user.</source>
        <translation>A eliminación do usuario fallou.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="722"/>
        <source>The group name needs to be at least 2 characters long. Please select a longer name before proceeding.</source>
        <translation>O nome do grupo ten que ter polo menos 2 caracteres. Escoller un nome máus comprimido.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="727"/>
        <source>The group name needs to be lower case and it 
cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>O nome do grupo ten que estar en minúsculas e
non pode econter caracteres especiais ou espazos.
Escoller outro nome.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="735"/>
        <source>Sorry, that group name already exists. Please enter a different name.</source>
        <translation>Este nome de grupo xa existe. Introducir un nome diferente.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="742"/>
        <source>No suitable group creation tools found (addgroup or groupadd).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="749"/>
        <source>The system group was added ok.</source>
        <translation>O grupo foi engadido correctamente.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="751"/>
        <source>Failed to add the system group.</source>
        <translation>Fallou engadir o grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="767"/>
        <source>This action cannot be undone. Are you sure you want to delete group %1?</source>
        <translation>Esta acción non pode ser revertida. Eliminar o grupo %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="768"/>
        <source>This action cannot be undone. Are you sure you want to delete the following groups: %1?</source>
        <translation>Esta acción non pode ser revertida. Estás seguro de que queres eliminar os seguintes grupos: %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="776"/>
        <source>No suitable group removal tools found (delgroup or groupdel).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="785"/>
        <source>Failed to delete the group.</source>
        <translation>Fallou a eliminación do grupo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="785"/>
        <source>Group: %1</source>
        <translation>Grupo: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="790"/>
        <source>The group has been deleted.</source>
        <translation>O grupo foi eliminado.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="790"/>
        <source>The groups have been deleted.</source>
        <translation>Os grupos foron eliminados.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="807"/>
        <source>The changes have been applied.</source>
        <translation>Os cambios foron aplicados.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="809"/>
        <source>Failed to apply group changes</source>
        <translation>A aplicación dos cambios fallou</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="677"/>
        <location filename="../mainwindow.cpp" line="824"/>
        <source>The selected user name is currently in use.</source>
        <translation>O nome do usuario seleccioando está en uso.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="825"/>
        <source>To rename this user, please log out and log back in using another user account.</source>
        <translation>Para renomear este usuario, saír da sesión e volver a entrar con outra conta de usuario.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="844"/>
        <source>Sorry, this name already exists on your system. Please enter a different name.</source>
        <translation>Este nome xa existe no sistema. Introducir un nome diferente.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="857"/>
        <source>Failed to rename the user. Please make sure that the user is not logged in, you might need to restart</source>
        <translation>Fallo ao renomear o usuario. Certificarse de que o usuario non está en sesión; pode ser necesario reiniciar.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="866"/>
        <source>The user was renamed.</source>
        <translation>O usuario foi renomeado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>Synchronizing desktop...ok</source>
        <translation>Sincronizando escritorio...feito</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>Copying desktop...ok</source>
        <translation>Copiando escritorio...concluído</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="894"/>
        <source>Synchronizing desktop...failed</source>
        <translation>Sincronizando escritorio...fallou</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="894"/>
        <source>Copying desktop...failed</source>
        <translation>Copiando escritorio...fallou</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="919"/>
        <source>Confirmation</source>
        <translation>Confirmación</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="920"/>
        <source>Process not done. Are you sure you want to quit the application?</source>
        <translation>Proceso non rematado. Estás seguro de que queres saír da aplicación?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1397"/>
        <source>About %1</source>
        <translation>Sobre %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1398"/>
        <source>Version: </source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1399"/>
        <source>Simple user configuration for MX Linux</source>
        <translation>Configuración simple dos usuarios para o MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1401"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1402"/>
        <source>%1 License</source>
        <translation>Licenza de %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1415"/>
        <source>%1 Help</source>
        <translation>Axuda para %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1432"/>
        <source>Select folder to copy to</source>
        <translation>Seleccionar cartafol para onde copiar</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="178"/>
        <source>Negligible</source>
        <translation>Insignificante</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="178"/>
        <source>Very weak</source>
        <translation>Moito débil</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="178"/>
        <source>Weak</source>
        <translation>Débil</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="179"/>
        <source>Moderate</source>
        <translation>Moderado</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="179"/>
        <source>Strong</source>
        <translation>Forte</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="179"/>
        <source>Very strong</source>
        <translation>Moito forte</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="180"/>
        <source>Password strength: %1</source>
        <translation>Forza do contrasinal: %1</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="216"/>
        <source>Hide the password</source>
        <translation>Agochar o contrasinal</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="216"/>
        <source>Show the password</source>
        <translation>Amosar o contrasinal</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="50"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="73"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="74"/>
        <location filename="../about.cpp" line="84"/>
        <source>Changelog</source>
        <translation>Rexistro dos cambios</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="75"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../about.cpp" line="30"/>
        <location filename="../about.cpp" line="99"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="81"/>
        <location filename="../main.cpp" line="89"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="82"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>O usuario parece ser root; para usar este programa, pechar a sesión e iniciar sesión como usuario normal.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="90"/>
        <source>You must run this program with admin access.</source>
        <translation>Debes executar este programa con acceso de administrador.</translation>
    </message>
</context>
</TS>