<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fa">
<context>
    <name>MEConfig</name>
    <message>
        <location filename="../mainwindow.ui" line="26"/>
        <source>MX User Manager</source>
        <translation>مدیریت کاربر MX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="62"/>
        <source>Administration</source>
        <translation>مدیریت سیستم</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="65"/>
        <source>Add a new user</source>
        <translation>یک کاربرجدید ایجاد کن</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="105"/>
        <source>Add User Account</source>
        <translation>یک اکانت جدید ایجاد کن</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="132"/>
        <source>Enter password for new user</source>
        <translation>رمزعبور برای کاربر جدید وارد کنید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="141"/>
        <source>password</source>
        <translation>رمز عبور</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="173"/>
        <source>Reenter password for new user</source>
        <translation>رمز عبور کاربر جدید را دوباره وارد کنید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>confirm password</source>
        <translation>تایید رمز عبور</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="198"/>
        <source>Username of new user</source>
        <translation>نام کاربری برای کاربر جدید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>User login name:</source>
        <translation>نام  ورود به سیستم:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="217"/>
        <location filename="../mainwindow.ui" line="466"/>
        <source>Enter username of new user</source>
        <translation>نام کاربری برای کاربرجدید وارد کنید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="223"/>
        <location filename="../mainwindow.ui" line="472"/>
        <source>username</source>
        <translation>نام کاربری</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="239"/>
        <location filename="../mainwindow.ui" line="258"/>
        <source>Password for new user</source>
        <translation>رمزعبور کاربرجدید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="242"/>
        <source>Confirm user password:</source>
        <translation>تایید رمزعبور:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>User password:</source>
        <translation>رمزعبور کاربر:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="271"/>
        <source>Grant this user administrative rights to the system (sudo)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="290"/>
        <source>Delete User Account</source>
        <translation>حذف اکانت کاربری</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="333"/>
        <source>Select user</source>
        <translation>انتخاب کاربر</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="349"/>
        <location filename="../mainwindow.ui" line="1436"/>
        <source>Select user to delete</source>
        <translation>کاربری که میخواهید حذف شود انتخاب کنید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="358"/>
        <source>User to delete:</source>
        <translation>این کاربر حذف می شود:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="374"/>
        <source>Also delete the user&apos;s home directory</source>
        <translation>همچنین پوشه home کاربر حذف شود</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="377"/>
        <source>Delete user home directory</source>
        <translation>پوشه home کاربر را حذف کن</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="396"/>
        <source>Rename User Account</source>
        <translation>تغییرنام اکانت کاربر</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="408"/>
        <location filename="../mainwindow.ui" line="570"/>
        <source>Select user to modify:</source>
        <translation>کاربر مورد نظر برای ویرایش را انتخاب کنید:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="450"/>
        <source>New user name:</source>
        <translation>نام کاربر جدید:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="491"/>
        <source>Change User Password</source>
        <translation>تغییر رمزعبور کاربر</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="519"/>
        <source>new password</source>
        <translation>رمزعبور جدید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="535"/>
        <source>Confirm new password:</source>
        <translation>تایید رمزعبور جدید:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="554"/>
        <source>confirm new password</source>
        <translation>تایید رمزعبور جدید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="586"/>
        <source>New user password:</source>
        <translation>رمزعبور کاربر جدید:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="620"/>
        <source>Options</source>
        <translation>تنظیمات</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="623"/>
        <source>Repair a user configuration</source>
        <translation>بازسازی تنظیمات مربوط به کاربر</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="657"/>
        <location filename="../mainwindow.ui" line="1393"/>
        <source>Modify User Account</source>
        <translation>ویرایش اکانت کاربری</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="669"/>
        <location filename="../mainwindow.ui" line="685"/>
        <source>Select user to repair</source>
        <translation>کاربر مورد نظر برای بازسازی را انتخاب کنید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="672"/>
        <location filename="../mainwindow.ui" line="1445"/>
        <source>User to change:</source>
        <translation>کاربر موردنظر:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="717"/>
        <source>Restore Defaults</source>
        <translation>بازگرداندن به حالت اولیه</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="738"/>
        <source>Restore browser configs to MX defaults</source>
        <translation>بازگرداندن تنظیمات مرورگر به حالت پیشفرض MX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="744"/>
        <source>Mozilla (Iceweasel or Firefox) configs</source>
        <translation>تنظیمات موزیلا(آیس ویزل یا فایرفاکس) </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="747"/>
        <source>Alt+X</source>
        <translation>Alt+X</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="754"/>
        <source>Restore group memberships to MX defaults</source>
        <translation>بازگرداندن عضویت گروه به حالت پیشفرض MX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="760"/>
        <source>Group memberships</source>
        <translation>عضویت گروه ها</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="763"/>
        <source>Alt+G</source>
        <translation>Alt+G</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="773"/>
        <source>Change Autologin Settings</source>
        <translation>ویرایش تنظیمات ورود خودکار</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="779"/>
        <source>Log in automatically</source>
        <translation>ورود خودکار</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="786"/>
        <source>Require password to log in</source>
        <translation>رمزعبور برای ورود به سیستم درخواست شود</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="801"/>
        <source>Copy/Sync</source>
        <translation>کپی / همگام سازی</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="828"/>
        <source>Copy Between Desktops</source>
        <translation>کپی از همه دسکتاپ ها</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="855"/>
        <location filename="../mainwindow.ui" line="922"/>
        <source>Select desktop to copy from</source>
        <translation>دسکتاپ مبدا برای کپی را انتخاب کنید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="868"/>
        <source>Select to only copy files</source>
        <translation>فقط فایل ها را کپی کن</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="871"/>
        <source>Copy only</source>
        <translation>فقط کپی</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="887"/>
        <location filename="../mainwindow.ui" line="900"/>
        <source>Select desktop to copy to</source>
        <translation>دسکتاپ مقصد برای کپی را انتخاب کنید</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="909"/>
        <source>Copy to:</source>
        <translation>کپی در:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="931"/>
        <source>Copy from:</source>
        <translation>کپی از:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="944"/>
        <source>Select to copy and then delete differences</source>
        <translation>انتخاب برای کپی و حذف متغایرها</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="947"/>
        <source>Sync</source>
        <translation>همگام سازی</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="993"/>
        <source>Select to copy/sync Shared</source>
        <translation>انتخاب برای کپی/همگام سازی پوشه اشتراک گذاری شده ها</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="996"/>
        <source>Shared folder</source>
        <translation>پوشه اشتراک گذاری شده ها</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1009"/>
        <source>Select to copy/sync entire home</source>
        <translation>انتخاب برای کپی/همگام سازی تمام پوشه خانه</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1012"/>
        <source>Entire home</source>
        <translation>کل پوشه خانه</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1028"/>
        <source>Select to copy/sync the browser configuration</source>
        <translation>انتخاب برای کپی/همگام سازی تنظیمات مرورگر</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1031"/>
        <source>Mozilla (Firefox or Iceweasel) configs</source>
        <translation>تنظیمات موزیلا(آیس ویزل یا فایرفاکس) </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1044"/>
        <source>Select to copy/sync Documents</source>
        <translation>انتخاب برای کپی/همگام سازی پوشه پرونده ها</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1047"/>
        <source>Documents folder</source>
        <translation>پوشه پرونده ها</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1054"/>
        <source>What to copy/sync:</source>
        <translation>مواردی که میخواهید کپی/همگام سازی کنید:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1070"/>
        <source>Progress</source>
        <translation>پیشرفت</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1100"/>
        <location filename="../mainwindow.ui" line="1116"/>
        <source>Status of the changes</source>
        <translation>وضعیت تغییرات</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1119"/>
        <source>Status:</source>
        <translation>وضعیت:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1135"/>
        <source>Progress of the changes</source>
        <translation>پیشرفت تغییرات اعمال شده</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1172"/>
        <source>Add/Remove Groups</source>
        <translation>اضافه/حذف گروه ها</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1184"/>
        <source>Add Group</source>
        <translation>اضافه کردن گروه</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1211"/>
        <source>Enter name of new group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1217"/>
        <source>groupname</source>
        <translation>نام گروه</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1227"/>
        <source>Create a group with GID &gt; 1000</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1230"/>
        <source>Create a user-level group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1259"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter name of new group&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1262"/>
        <source>Group name:</source>
        <translation>نام گروه:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1281"/>
        <source>Delete Group</source>
        <translation>حذف گروه</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1350"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select group to delete&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1359"/>
        <source>Select group to delete:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1366"/>
        <source>*Please doublecheck your selections before applying, removing a wrong group can break your system.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1381"/>
        <source>Group Membership</source>
        <translation>عضویت های گروه</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1455"/>
        <source>Groups user belongs to (change the groups by selecting/deselecting the appropriate boxes):</source>
        <translation>گروه هایی که این کاربر در آن عضویت دارد( برای تغییر گروه ها گزینه های مناسب را انتخاب کنید):</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1478"/>
        <source>*Please doublecheck your selections before applying, assigning wrong group memberships can break your system. If you made a mistake, use restore group membership in Options tab to restore the defaults.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1507"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select user to change&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1583"/>
        <source>Cancel any changes then quit</source>
        <translation>همه تغییرات را نادیده بگیر و خارج شو</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1586"/>
        <source>Close</source>
        <translation>بستن</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1593"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1634"/>
        <source>Display help </source>
        <translation>نمایش راهنما</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1637"/>
        <source>Help</source>
        <translation>راهنما </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1644"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1651"/>
        <source>Apply any changes</source>
        <translation>اعمال تغییرت</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1654"/>
        <source>Apply</source>
        <translation>اعمال</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1661"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1668"/>
        <source>About this application</source>
        <translation>درباره این نرم افزار</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1671"/>
        <source>About...</source>
        <translation>درباره...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1678"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="157"/>
        <location filename="../mainwindow.cpp" line="165"/>
        <location filename="../mainwindow.cpp" line="192"/>
        <location filename="../mainwindow.cpp" line="813"/>
        <location filename="../mainwindow.cpp" line="843"/>
        <location filename="../mainwindow.cpp" line="1000"/>
        <location filename="../mainwindow.cpp" line="1067"/>
        <location filename="../mainwindow.cpp" line="1074"/>
        <location filename="../mainwindow.cpp" line="1079"/>
        <location filename="../mainwindow.cpp" line="1084"/>
        <location filename="../mainwindow.cpp" line="1089"/>
        <source>none</source>
        <translation>هیچکدام</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <location filename="../mainwindow.cpp" line="777"/>
        <location filename="../mainwindow.cpp" line="1007"/>
        <location filename="../mainwindow.cpp" line="1016"/>
        <source>browse...</source>
        <translation>مرورگر...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="208"/>
        <source>The user configuration will be repaired. Please close all other applications now. When finished, please logout or reboot. Are you sure you want to repair now?</source>
        <translation>تنظیمات کاربری بازسازی خواهد شد.اکنون لطفا تمامی برنامه های درحال اجرا را ببندید. بعد از اتمام عملیات سیستم را ری استارت نمایید. آیا درباره بازسازی تنظیمات مطمئن هستید؟ </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="230"/>
        <source>User group membership was restored.</source>
        <translation>تنظیمات مربوط  به عضویت گروه ها بازنشانی شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="235"/>
        <source>Mozilla settings were reset.</source>
        <translation>تنظیمات موزیلا بازنشانی شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="250"/>
        <location filename="../mainwindow.cpp" line="281"/>
        <source>Autologin options</source>
        <translation>تنظیمات ورود خودکار</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="251"/>
        <source>Autologin has been disabled for the &apos;%1&apos; account.</source>
        <translation>ورود خودکار برای کاربر &apos;1%&apos; غیرفعال شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="282"/>
        <source>Autologin has been enabled for the &apos;%1&apos; account.</source>
        <translation>ورود خودکار برای کاربر &apos;1%&apos; فعال شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="294"/>
        <source>You must specify a &apos;copy to&apos; destination. You cannot copy to the desktop you are logged in to.</source>
        <translation>شما باید برای کپی یک مقصد تعیین کنید. شما نمی توانید مقصد را دسکتاپی که وارد آن شده اید انتخاب کنید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="300"/>
        <source>Before copying, close all other applications. Be sure the copy to destination is large enough to contain the files you are copying. Copying between desktops may overwrite or delete your files or preferences on the destination desktop. Are you sure you want to proceed?</source>
        <translation>قبل از کپی کردن؛ تمامی برنامه های درحال اجرا را ببندید. از وجود فضای کافی در مقصد اطمینان حاصل نمایید. کپی فایل بین دو دسکتاپ ممکن است موجب بازنویسی یا حذف فایل های موجود در دسکتاپ مقصد شود. آیا برای ادامه عملیات مطمئن هستید؟</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="326"/>
        <source>Synchronizing desktop...</source>
        <translation>همگام سازی دسکتاپ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="328"/>
        <source>Copying desktop...</source>
        <translation>درحال کپی دسکتاپ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="365"/>
        <location filename="../mainwindow.cpp" line="598"/>
        <source>The user name needs to be at least 2 characters long. Please select a longer name before proceeding.</source>
        <translation>رمز عبور باید حداقل 2  کاراکتر باشد. لطفا یک نام بلندتر وارد نمایید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="370"/>
        <location filename="../mainwindow.cpp" line="603"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="376"/>
        <source>Sorry, this name is in use. Please enter a different name.</source>
        <translation>خطا - این نام درحال حاضر اختصاص داده شده است. لطفا نام دیگری وارد نمایید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="380"/>
        <location filename="../mainwindow.cpp" line="436"/>
        <source>Password entries do not match. Please try again.</source>
        <translation>گذرواژه های وارد شده منطبق نمی باشند. لطفا دوباره تلاش کنید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="385"/>
        <location filename="../mainwindow.cpp" line="441"/>
        <source>Password needs to be at least 2 characters long. Please enter a longer password before proceeding.</source>
        <translation>گذرواژه  باید حداقل 2 کاراکترباشد. لطفا یک گذرواژه بلندتر وارد نمایید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="425"/>
        <source>The user was added ok.</source>
        <translation>کاربر با موفقیت اضافه شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="428"/>
        <source>Failed to add the user.</source>
        <translation>اضافه کردن کاربر با خطا روبرو شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="456"/>
        <source>Password successfully changed.</source>
        <translation>گذرواژه با موفقیت تغییر یافت.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="459"/>
        <source>Failed to change password.</source>
        <translation>تغییر گذرواژه با خطا روبرو شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="465"/>
        <source>This action cannot be undone. Are you sure you want to delete user %1?</source>
        <translation>این عمل غیر قابل بازگشت می باشد. آیا از حذف کاربر 1% مطمئن هستید؟</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="484"/>
        <source>The user has been deleted.</source>
        <translation>کاربرحذف شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="486"/>
        <source>Failed to delete the user.</source>
        <translation>حذف کاربر با خطا روبرو شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="500"/>
        <source>The group name needs to be at least 2 characters long. Please select a longer name before proceeding.</source>
        <translation>نام گروه باید حداقل 2 کاراکتر باشد. لطفا یک نام بلدتر وارد نمایید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>The group name needs to be lower case and it 
cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>نام گروه باید با حروف کوچک نوشته شود و
نمی تواند دارای فاصله یا کاراکترهای خاص باشد.
لطفا یک نام گروه مناسب انتخاب کنید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>Sorry, that group name already exists. Please enter a different name.</source>
        <translation>خطا - گروه با این نام درحال حاضر اختصاص داده شده است. لطفا نام دیگری وارد نمایید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="521"/>
        <source>The system group was added ok.</source>
        <translation>گروه سیستم با موفقیت اضافه شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="523"/>
        <source>Failed to add the system group.</source>
        <translation>خطا هنگام اضافه کردن گروه سیستم.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="538"/>
        <source>This action cannot be undone. Are you sure you want to delete group %1?</source>
        <translation>این عمل غیر قابل بازگشت می باشد. آیا از حذف گروه 1% مطمئن هستید؟</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="539"/>
        <source>This action cannot be undone. Are you sure you want to delete the following groups: %1?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="548"/>
        <source>Failed to delete the group.</source>
        <translation>حذف گروه  با خطا روبرو شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="548"/>
        <source>Group: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="552"/>
        <source>The group has been deleted.</source>
        <translation>گروه حذف شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="552"/>
        <source>The groups have been deleted.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="569"/>
        <source>The changes have been applied.</source>
        <translation>تغییرات اعمال شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="571"/>
        <source>Failed to apply group changes</source>
        <translation>خطا هنگام اعمال تعییرات گروه.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>The selected user name is currently in use.</source>
        <translation>نام کاربری انتخاب شده هم اکنون درحال استفاده است.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="590"/>
        <source>To rename this user, please log out and log back in using another user account.</source>
        <translation>برای تغییر نام کاربر فعلی می بایست logout کنید و با یک نام کاربری دیگر login کنید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="609"/>
        <source>Sorry, this name already exists on your system. Please enter a different name.</source>
        <translation>خطا - این نام در حال حاضر روی سیستم موجود است. یک نام دیگر انتخاب کنید.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="621"/>
        <source>Failed to rename the user. Please make sure that the user is not logged in, you might need to restart</source>
        <translation>خطا - تغییر نام کاربر امکان پذیر نیست. مطمئن شوید که کاربر وارد سیستم نشده باشد. ممکن است نیاز به راه اندازی مجدد سیستم باشد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="654"/>
        <source>The user was renamed.</source>
        <translation>نام کاربر تغییر داده شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="666"/>
        <location filename="../mainwindow.cpp" line="694"/>
        <source>Synchronizing desktop...ok</source>
        <translation>همگام سازی دسکتاپ ... موفق.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="668"/>
        <location filename="../mainwindow.cpp" line="696"/>
        <source>Copying desktop...ok</source>
        <translation>عملیات کپی دسکتاپ ... موفق.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="700"/>
        <source>Synchronizing desktop...failed</source>
        <translation>همگام سازی دسکتاپ ... با خطا روبرو شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="702"/>
        <source>Copying desktop...failed</source>
        <translation>عملیات کپی دسکتاپ ... با خطا روبرو شد.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="721"/>
        <source>Confirmation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="722"/>
        <source>Process not done. Are you sure you want to quit the application?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="972"/>
        <source>About %1</source>
        <translation>درباره 1%</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="973"/>
        <source>Version: </source>
        <translation>نسخه:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="974"/>
        <source>Simple user configuration for MX Linux</source>
        <translation>تنظیمات کاربری آسان MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="976"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="977"/>
        <source>%1 License</source>
        <translation>مجوز 1%</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="991"/>
        <source>%1 Help</source>
        <translation>راهنمای 1%</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1008"/>
        <source>Select folder to copy to</source>
        <translation>پوشه مقصد برای کپی را انتخاب کنید</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="162"/>
        <source>Negligible</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../passedit.cpp" line="162"/>
        <source>Very weak</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../passedit.cpp" line="162"/>
        <source>Weak</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../passedit.cpp" line="163"/>
        <source>Moderate</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../passedit.cpp" line="163"/>
        <source>Strong</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../passedit.cpp" line="163"/>
        <source>Very strong</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../passedit.cpp" line="164"/>
        <source>Password strength: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../passedit.cpp" line="200"/>
        <source>Hide the password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../passedit.cpp" line="200"/>
        <source>Show the password</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="50"/>
        <source>License</source>
        <translation>لایسنس</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <location filename="../about.cpp" line="61"/>
        <source>Changelog</source>
        <translation>لیست موارد بهبود یافته</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="52"/>
        <source>Cancel</source>
        <translation>لغو</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="74"/>
        <source>&amp;Close</source>
        <translation>و بستن</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="66"/>
        <location filename="../main.cpp" line="74"/>
        <source>Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../main.cpp" line="67"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>